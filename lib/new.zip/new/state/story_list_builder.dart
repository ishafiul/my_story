import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:story/new/state/data.dart';
import 'package:story/story.dart';

/// [GG] is the main, and and only widget you need to
/// archive pagination
class GG<T> extends StatefulWidget {
  /// [GG] is the main, and and only widget you need to
  /// archive pagination
  const GG({
    super.key,
    this.scrollDirection = Axis.vertical,
    required this.onInit,
    required this.builder,
    required this.onLoad,
    this.padding,
    this.onInitialLoading,
    this.onLoadMoreLoading,
    this.topWidget,
    this.bottomWidget,
    this.onNoData,
    this.itemPadding,
    this.initPage = 1,
  });

  ///  [onInit] is a required argument for the [GG] widget.
  ///  It takes a function that will return [OnInit]
  /// [OnInit] can be `FutureOr<Iterable<T>>`
  /// This function will call on `initState` of [GG]'s life cycle
  final OnInit<T> onInit;

  /// [onLoad] is a required argument for the [GG] widget.
  /// It takes a function that will return [OnLoad]
  /// [OnLoad] can be `FutureOr<Iterable<T>>`
  /// This function will call when the user reached to
  /// the end of the list of data
  final OnLoad<T> onLoad;

  /// [onInitialLoading] is a widget that will display until
  /// the initial data is loaded
  final Widget? onInitialLoading;

  /// [onLoadMoreLoading] is a widget at end of the list that will display
  /// when waiting for a response on a pagination API request
  final Widget? onLoadMoreLoading;
  final Axis scrollDirection;

  /// [onNoData] is a widget that will have no more data to display
  final Widget? onNoData;

  /// you can pass an additional widget that will display on top of the list
  final Widget? topWidget;

  /// you can pass an additional widget that will display on the bottom of
  /// the list
  final Widget? bottomWidget;

  /// [initPage] will take a [int] value representing the initial
  /// circle of requests. by default its is  `1`
  final int? initPage;

  /// padding for [GG] widget
  final EdgeInsetsGeometry? padding;

  /// padding for [GG] widget's items

  final EdgeInsetsGeometry? itemPadding;

  /// builder will [BuildContext] and `itemData` as a single item.
  /// and it will expect a widget that will represent a single item
  final ItemBuilder<T> builder;

  @override
  State<GG<T>> createState() => _GGState<T>();
}

class _GGState<T> extends State<GG<T>> {
  final scrollController = ScrollController();
  bool isLoading = false;

  //late ValueNotifier<Iterable<T>> data = ValueNotifier([]);
  int index = 0;
  bool isInitData = false;
  bool isNoData = false;

  Future<void> initData() async {
    final dataa = await widget.onInit();
    // data.value = dataa;
    Provider.of<StoryDataNotifier>(context, listen: false).addData(dataa);
    setState(() {
      isInitData = true;
    });
  }

  @override
  void initState() {
    initData();
    setState(() {
      index = widget.initPage != null ? widget.initPage! + 1 : 2;
    });
    scrollController.addListener(() async {
      if (isNoData == false) {
        if (scrollController.position.pixels ==
            scrollController.position.maxScrollExtent) {
          if (!mounted) return;

          setState(() {
            isLoading = true;
            print(isLoading);
          });
          final newData = await widget.onLoad(index++);
          if (newData == null || newData.isEmpty) {
            setState(() {
              isNoData = true;
            });
          } else {
            setState(() {
              index = index++;
            });
            Provider.of<StoryDataNotifier>(context, listen: false)
                .addData(newData);
            //data.value = [...data.value, ...newData];
          }
          setState(() {
            isLoading = false;
          });
        }
      }
    });

    _stateListener(){
      final fg = context.watch<StoryDataNotifier>().data;
    }
    super.initState();
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.scrollDirection == Axis.vertical)
      return ListView(
        controller: scrollController,
        children: [
          if (isInitData == false) widget.onInitialLoading ?? const SizedBox(),
          widget.topWidget ?? const SizedBox(),
          Consumer<StoryDataNotifier>(
              builder: (BuildContext context, value, Widget? child) {
            return ListView.builder(
              padding: widget.padding,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: value.data.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: widget.itemPadding ?? EdgeInsets.zero,
                  child: widget.builder(context, value.data.elementAt(index)),
                );
              },
            );
          }),
          if (isLoading) widget.onLoadMoreLoading ?? const SizedBox(),
          if (isNoData) widget.onNoData ?? const SizedBox(),
          widget.bottomWidget ?? const SizedBox(),
        ],
      );
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      scrollDirection: Axis.horizontal,
      controller: scrollController,
      child: Wrap(
        spacing: 12,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        runAlignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.start,
        children: [
          Consumer<StoryDataNotifier>(
              builder: (BuildContext context, value, Widget? child) {
            return Row(
                children: List.generate(value.data.length, (index) {
              return Padding(
                padding: widget.itemPadding ?? EdgeInsets.zero,
                child: GestureDetector(
                    onTap: () {
                      print(index);
                    },
                    child:
                        widget.builder(context, value.data.elementAt(index))),
              );
            }));
          })
        ],
      ),
    );
  }
}
